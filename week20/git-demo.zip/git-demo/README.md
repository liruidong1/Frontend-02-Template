# A sample change

# prevent change


# prevent change1

# git command
```shell script
git stash push
git stash list
git stash pop
```

# chrome command
```shell script
alias chrome="/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome"
chrome --headless --dump-dom about:blank
```

