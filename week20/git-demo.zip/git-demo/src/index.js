for(let i of [1,2,3]) {
    console.log(i)
}

